chrome.action.onClicked.addListener(async (tab) => {
    try {
        await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            function: () => {
                const downloadBtn = document.createElement('button');
                downloadBtn.innerHTML = 'Download Video';
                downloadBtn.id = 'video-download-btn';
                downloadBtn.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    z-index: 999999;
                    padding: 10px 20px;
                    background: #ff0000;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                    font-size: 16px;
                    font-weight: bold;
                `;
                
                downloadBtn.onclick = () => {
                    const pageSource = document.documentElement.outerHTML;
                    const regex = /html5player\.setVideoUrlHigh\('([^']+)'\)/;
                    const match = pageSource.match(regex);
                    
                    if (match && match[1]) {
                        const videoUrl = match[1];
                        const link = document.createElement('a');
                        link.href = videoUrl;
                        link.download = 'video.mp4';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    } else {
                        alert('Video URL not found!');
                    }
                };

                // Remove existing button if it exists
                const existingBtn = document.getElementById('video-download-btn');
                if (existingBtn) {
                    existingBtn.remove();
                } else {
                    document.body.appendChild(downloadBtn);
                }
            }
        });
    } catch (err) {
        console.error(err);
    }
}); 
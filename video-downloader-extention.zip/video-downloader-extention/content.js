let downloadBtn = null;

// Create the button but don't add it to the page yet
function createButton() {
    if (!downloadBtn) {
        downloadBtn = document.createElement('button');
        downloadBtn.innerHTML = 'Download Video';
        downloadBtn.style.cssText = 'position: fixed; top: 10px; right: 10px; z-index: 9999; padding: 10px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer;';
        
        downloadBtn.addEventListener('click', function() {
            const pageSource = document.documentElement.outerHTML;
            const regex = /html5player\.setVideoUrlHigh\('([^']+)'\)/;
            const match = pageSource.match(regex);
            
            if (match && match[1]) {
                const videoUrl = match[1];
                const link = document.createElement('a');
                link.href = videoUrl;
                link.download = 'video.mp4';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            } else {
                alert('Video URL not found!');
            }
        });
    }
}

// Toggle button visibility
function toggleButton() {
    if (!downloadBtn) {
        createButton();
    }
    
    if (downloadBtn.parentElement) {
        document.body.removeChild(downloadBtn);
    } else {
        document.body.appendChild(downloadBtn);
    }
}

// Listen for messages from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "toggleDownloadButton") {
        toggleButton();
    }
}); 